﻿namespace Eventures.Web.Models.Events
{
    public class MyEventViewModel
    {
        public string Name { get; set; }

        public string Start { get; set; }

        public string End { get; set; }

        public int Tickets { get; set; }
    }
}
