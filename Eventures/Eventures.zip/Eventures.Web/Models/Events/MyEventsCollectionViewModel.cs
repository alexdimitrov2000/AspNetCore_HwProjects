﻿using System.Collections.Generic;

namespace Eventures.Web.Models.Events
{
    public class MyEventsCollectionViewModel
    {
        public List<MyEventViewModel> MyEvents { get; set; }
    }
}
