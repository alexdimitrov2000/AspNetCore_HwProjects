﻿using System.Collections.Generic;

namespace Eventures.Web.Models.Events
{
    public class EventCollectionViewModel
    {
        public List<EventViewModel> Events { get; set; }
    }
}
