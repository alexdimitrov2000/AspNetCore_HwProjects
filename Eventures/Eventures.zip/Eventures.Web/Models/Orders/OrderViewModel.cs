﻿namespace Eventures.Web.Models.Orders
{
    public class OrderViewModel
    {
        public string EventName { get; set; }

        public string CustomerName { get; set; }

        public string OrderedOn { get; set; }
    }
}
