﻿using System.Collections.Generic;

namespace Eventures.Web.Models.Orders
{
    public class OrderCollectionViewModel
    {
        public List<OrderViewModel> Orders { get; set; }
    }
}
