﻿namespace Eventures.Web
{
    public static class GlobalConstants
    {
        public const int NumberOfEntitiesOnPage = 5;
    }
}
