﻿using System.Collections.Generic;

namespace Chushka.App.Models.Home
{
    public class ProductCollectionViewModel
    {
        public List<IndexProductViewModel> Products { get; set; }
    }
}
