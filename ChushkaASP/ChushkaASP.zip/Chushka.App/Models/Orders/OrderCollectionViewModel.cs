﻿using System.Collections.Generic;

namespace Chushka.App.Models.Orders
{
    public class OrderCollectionViewModel
    {
        public List<OrderViewModel> Orders { get; set; }
    }
}
