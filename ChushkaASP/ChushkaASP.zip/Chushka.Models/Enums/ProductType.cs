﻿namespace Chushka.Models.Enums
{
    public enum ProductType
    {
        Food = 0,
        Domestic = 1,
        Health = 2,
        Cosmetic = 3,
        Other = 4
    }
}
